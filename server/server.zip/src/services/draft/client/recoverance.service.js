module.exports = (server) => { return {
    name: "draft/client/recoverance",
    actions: {
        start(){

        }
    }
}}