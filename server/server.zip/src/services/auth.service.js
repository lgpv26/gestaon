module.exports = (server) => { return {
    name: "auth",
    actions: {
        get(ctx) {
        },
        list(ctx){
        },
        create(ctx){
        },
        update(ctx){
        },
        remove(ctx){
        }
    }
}}