import { resolve } from 'dns';

const basePath = require('../../../middlewares/base-path.middleware')
const _ = require('lodash')

module.exports = class Draft {

    constructor(server) {

    }

    getDraftById(draftId){
    }

};